src/tools/apinames -wV include/freetype/*.h > freetype_vms0.opt
/gnu/bin/mv freetype_vms0.opt freetype_vms.opt
