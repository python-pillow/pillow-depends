# Unicode Character Database
# Date: 2024-08-25
# © 2024 Unicode®, Inc.
# Unicode and the Unicode Logo are registered trademarks of Unicode, Inc. in the U.S. and other countries.
# For terms of use and license, see https://www.unicode.org/terms_of_use.html
#
# For documentation, see the following:
# NamesList.html
# UAX #38, "Unicode Han Database (Unihan)"
# UAX #44, "Unicode Character Database"
# UTS #51, "Unicode Emoji"
# UAX #57, "Unicode Egyptian Hieroglyph Database"
#
# The UAXes and UTS #51 can be accessed at https://www.unicode.org/versions/Unicode16.0.0/

This directory contains final data files
for the Unicode Character Database, for Version 16.0.0 of the Unicode Standard.
