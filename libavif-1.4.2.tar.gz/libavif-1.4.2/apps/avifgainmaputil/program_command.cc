#include "program_command.h"

#include <vector>

#include "avifutil.h"

namespace avif {

ProgramCommand::ProgramCommand(const std::string& name,
                               const std::string& short_description,
                               const std::string& long_description)
    : argparse_(argparse::ArgumentParser(
          "avifgainmaputil " + name,
          short_description + ".\n" + long_description)),
      name_(name),
      short_description_(short_description) {}

// Parses command line arguments. Should be called before Run().
avifResult ProgramCommand::ParseArgs(int argc, const char* const argv[]) {
  argparse_.parse_args(argc, argv);
  return AVIF_RESULT_OK;
}

// Prints this command's help on stdout.
void ProgramCommand::PrintUsage() { argparse_.print_help(); }

argparse::ConvertedValue<int> PixelFormatConverter::from_str(
    const std::string& str) {
  argparse::ConvertedValue<int> converted_value;

  if (str == "444") {
    converted_value.set_value(AVIF_PIXEL_FORMAT_YUV444);
  } else if (str == "422") {
    converted_value.set_value(AVIF_PIXEL_FORMAT_YUV422);
  } else if (str == "420") {
    converted_value.set_value(AVIF_PIXEL_FORMAT_YUV420);
  } else if (str == "400") {
    converted_value.set_value(AVIF_PIXEL_FORMAT_YUV400);
  } else {
    converted_value.set_error("Invalid argument value");
  }
  return converted_value;
}

std::vector<std::string> PixelFormatConverter::default_choices() {
  return {"444", "422", "420", "400"};
}

argparse::ConvertedValue<CicpValues> CicpConverter::from_str(
    const std::string& str) {
  argparse::ConvertedValue<CicpValues> converted_value;

  std::vector<uint32_t> cicp_values;
  if (!ParseList(str, '/', 3, &cicp_values)) {
    converted_value.set_error(
        "Invalid CICP values, expected format: P/T/M where each "
        "value is a positive integer, got: " +
        str);
    return converted_value;
  }

  CicpValues cicp = {};
  cicp.color_primaries = (avifColorPrimaries)cicp_values[0];
  cicp.transfer_characteristics = (avifTransferCharacteristics)cicp_values[1];
  cicp.matrix_coefficients = (avifMatrixCoefficients)cicp_values[2];
  converted_value.set_value(cicp);

  return converted_value;
}

std::vector<std::string> CicpConverter::default_choices() { return {}; }

argparse::ConvertedValue<avifContentLightLevelInformationBox>
ClliConverter::from_str(const std::string& str) {
  argparse::ConvertedValue<avifContentLightLevelInformationBox> converted_value;

  std::vector<uint16_t> clli;
  if (!ParseList(str, ',', 2, &clli)) {
    converted_value.set_error(
        "Invalid CLLI values, expected format: maxCLL,maxPALL where "
        "both maxCLL and maxPALL are positive integers, got: " +
        str);
    return converted_value;
  }
  avifContentLightLevelInformationBox clli_box = {};
  clli_box.maxCLL = clli[0];
  clli_box.maxPALL = clli[1];
  converted_value.set_value(clli_box);

  return converted_value;
}

std::vector<std::string> ClliConverter::default_choices() { return {}; }

argparse::ConvertedValue<GridOptions> GridOptionsConverter::from_str(
    const std::string& str) {
  argparse::ConvertedValue<GridOptions> converted_value;

  std::vector<int> grid_dims;
  if (!ParseList(str, 'x', 2, &grid_dims) || grid_dims[0] <= 0 ||
      grid_dims[1] <= 0) {
    converted_value.set_error("Invalid grid dimensions: " + str);
    return converted_value;
  }
  GridOptions grid_options = {grid_dims[0], grid_dims[1]};

  converted_value.set_value(grid_options);

  return converted_value;
}

std::vector<std::string> GridOptionsConverter::default_choices() { return {}; }

argparse::ConvertedValue<int> JobsConverter::from_str(const std::string& str) {
  argparse::ConvertedValue<int> converted_value;

  if (str == "all") {
    converted_value.set_value(avifQueryCPUCount());
  } else {
    int jobs;
    try {
      jobs = std::stoi(str);
    } catch (...) {
      converted_value.set_error("Invalid jobs value: " + str);
      return converted_value;
    }
    if (jobs < 1) {
      jobs = 1;
    }
    converted_value.set_value(jobs);
  }

  return converted_value;
}

std::vector<std::string> JobsConverter::default_choices() { return {}; }

}  // namespace avif
