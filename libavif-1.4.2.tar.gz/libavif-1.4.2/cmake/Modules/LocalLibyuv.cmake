# When changing the commit below to a newer version of libyuv, it is best to make sure it is being used by chromium,
# because the test suite of chromium provides additional test coverage of libyuv.
# It can be looked up at https://source.chromium.org/chromium/chromium/src/+/main:DEPS?q=libyuv.
set(AVIF_LIBYUV_TAG "644251f252a84bf8ce91ff0aca86a9b16b069ab8")

set(AVIF_LIBYUV_BUILD_DIR "${AVIF_SOURCE_DIR}/ext/libyuv/build")
# If ${ANDROID_ABI} is set, look for the library under that subdirectory.
if(DEFINED ANDROID_ABI)
    set(AVIF_LIBYUV_BUILD_DIR "${AVIF_LIBYUV_BUILD_DIR}/${ANDROID_ABI}")
endif()
set(LIB_FILENAME "${AVIF_LIBYUV_BUILD_DIR}/${AVIF_LIBRARY_PREFIX}yuv${CMAKE_STATIC_LIBRARY_SUFFIX}")

if(EXISTS "${LIB_FILENAME}")
    message(STATUS "libavif(AVIF_LIBYUV=LOCAL): compiled library found at ${LIB_FILENAME}")
    set(LIBYUV_INCLUDE_DIR "${AVIF_SOURCE_DIR}/ext/libyuv/include")

    add_library(yuv::yuv STATIC IMPORTED GLOBAL)
    set_target_properties(yuv::yuv PROPERTIES IMPORTED_LOCATION "${LIB_FILENAME}" AVIF_LOCAL ON)
    target_include_directories(yuv::yuv INTERFACE "${LIBYUV_INCLUDE_DIR}")
    set_target_properties(yuv::yuv PROPERTIES FOLDER "ext/libyuv")
else()
    message(STATUS "libavif(AVIF_LIBYUV=LOCAL): compiled library not found at ${LIB_FILENAME}; using FetchContent")
    if(EXISTS "${AVIF_SOURCE_DIR}/ext/libyuv")
        message(STATUS "libavif(AVIF_LIBYUV=LOCAL): ext/libyuv found; using as FetchContent SOURCE_DIR")
        set(FETCHCONTENT_SOURCE_DIR_LIBYUV "${AVIF_SOURCE_DIR}/ext/libyuv")
        message(CHECK_START "libavif(AVIF_LIBYUV=LOCAL): configuring libyuv")
    else()
        message(CHECK_START "libavif(AVIF_LIBYUV=LOCAL): fetching and configuring libyuv")
    endif()

    # unset JPEG_FOUND so that libyuv does not find it
    set(JPEG_FOUND_ORIG ${JPEG_FOUND})
    unset(JPEG_FOUND CACHE)
    set(CMAKE_DISABLE_FIND_PACKAGE_JPEG TRUE)

    FetchContent_Declare(
        libyuv
        EXCLUDE_FROM_ALL
        GIT_REPOSITORY "https://chromium.googlesource.com/libyuv/libyuv"
        GIT_TAG "${AVIF_LIBYUV_TAG}"
        UPDATE_COMMAND ""
    )

    avif_fetchcontent_makeavailable_cmake(libyuv)

    set(JPEG_FOUND ${JPEG_FOUND_ORIG})
    unset(JPEG_FOUND_ORIG CACHE)
    set(CMAKE_DISABLE_FIND_PACKAGE_JPEG FALSE)

    set_target_properties(yuv PROPERTIES AVIF_LOCAL ON POSITION_INDEPENDENT_CODE ON)

    add_library(yuv::yuv ALIAS yuv)

    set(LIBYUV_INCLUDE_DIR "${libyuv_SOURCE_DIR}/include")

    target_include_directories(yuv INTERFACE ${LIBYUV_INCLUDE_DIR})

    if(EXISTS "${AVIF_SOURCE_DIR}/ext/libyuv")
        set_target_properties(yuv PROPERTIES FOLDER "ext/libyuv")
    endif()

    message(CHECK_PASS "complete")
endif()

set(libyuv_FOUND ON)

set(LIBYUV_VERSION_H "${LIBYUV_INCLUDE_DIR}/libyuv/version.h")
if(EXISTS ${LIBYUV_VERSION_H})
    # message(STATUS "Reading: ${LIBYUV_VERSION_H}")
    file(READ ${LIBYUV_VERSION_H} LIBYUV_VERSION_H_CONTENTS)
    string(REGEX MATCH "#define LIBYUV_VERSION ([0-9]+)" _ ${LIBYUV_VERSION_H_CONTENTS})
    set(LIBYUV_VERSION ${CMAKE_MATCH_1})
    # message(STATUS "libyuv version detected: ${LIBYUV_VERSION}")
endif()
if(NOT LIBYUV_VERSION)
    message(STATUS "libyuv version detection failed.")
endif()
