set(AVIF_AVM_GIT_TAG research-v15.0.0)

message(CHECK_START "libavif(AVIF_CODEC_AVM=LOCAL): fetching and configuring avm")

# avm sets its compile options by setting variables like CMAKE_C_FLAGS_RELEASE using
# CACHE FORCE, which effectively adds those flags to all targets. We stash and restore
# the original values and call avif_set_avm_compile_options to instead set the flags on all avm
# targets
function(avif_set_avm_compile_options target config)
    string(REPLACE " " ";" AVM_C_FLAGS_LIST "${CMAKE_C_FLAGS_${config}}")
    string(REPLACE " " ";" AVM_CXX_FLAGS_LIST "${CMAKE_CXX_FLAGS_${config}}")
    foreach(flag ${AVM_C_FLAGS_LIST})
        target_compile_options(${target} PRIVATE $<$<COMPILE_LANGUAGE:C>:${flag}>)
    endforeach()
    foreach(flag ${AVM_CXX_FLAGS_LIST})
        target_compile_options(${target} PRIVATE $<$<COMPILE_LANGUAGE:CXX>:${flag}>)
    endforeach()

    get_target_property(sources ${target} SOURCES)
    foreach(src ${sources})
        if(src MATCHES "TARGET_OBJECTS:")
            string(REGEX REPLACE "\\$<TARGET_OBJECTS:(.*)>" "\\1" source_target ${src})
            avif_set_avm_compile_options(${source_target} ${config})
        endif()
    endforeach()
endfunction()

FetchContent_Declare(
    libavm
    EXCLUDE_FROM_ALL
    GIT_REPOSITORY "https://github.com/AOMediaCodec/avm.git"
    GIT_TAG ${AVIF_AVM_GIT_TAG}
    GIT_PROGRESS ON
    GIT_SHALLOW ON
    UPDATE_COMMAND ""
)
# There can be a duplicate cpuinfo in SVT so find_package has to be used.
set(RUY_FIND_CPUINFO ON CACHE INTERNAL "")
# TODO(vrabaud) Remove once libavm properly depends on flatbuffers.
include_directories(${CMAKE_CURRENT_BINARY_DIR}/flatbuffers/include/)

set(CONFIG_PIC 1 CACHE INTERNAL "")
if(libyuv_FOUND)
    set(CONFIG_LIBYUV 0 CACHE INTERNAL "")
else()
    set(CONFIG_LIBYUV 1 CACHE INTERNAL "")
endif()
set(CONFIG_WEBM_IO 0 CACHE INTERNAL "")
set(ENABLE_DOCS 0 CACHE INTERNAL "")
set(ENABLE_EXAMPLES 0 CACHE INTERNAL "")
set(ENABLE_TESTDATA 0 CACHE INTERNAL "")
set(ENABLE_TESTS 0 CACHE INTERNAL "")
set(ENABLE_TOOLS 0 CACHE INTERNAL "")
if(CMAKE_OSX_ARCHITECTURES STREQUAL "arm64")
    set(AVM_TARGET_CPU "arm64")
endif()

if(NOT libavm_POPULATED)
    # Guard against the project setting cmake variables that would affect the parent build
    # See comment above for avif_set_avm_compile_options
    foreach(_config_setting CMAKE_C_FLAGS CMAKE_CXX_FLAGS CMAKE_EXE_LINKER_FLAGS)
        foreach(_config_type DEBUG RELEASE MINSIZEREL RELWITHDEBINFO)
            set(${_config_setting}_${_config_type}_ORIG ${${_config_setting}_${_config_type}})
        endforeach()
    endforeach()

    avif_fetchcontent_makeavailable_cmake(libavm)

    set(_avm_config RELEASE)
    if(CMAKE_BUILD_TYPE)
        string(TOUPPER ${CMAKE_BUILD_TYPE} _avm_config)
    endif()
    list(LENGTH CMAKE_CONFIGURATION_TYPES num_configs)
    if(${num_configs} GREATER 0)
        list(GET CMAKE_CONFIGURATION_TYPES 0 _avm_config_type)
        string(TOUPPER ${_avm_config_type} _avm_config)
    endif()
    avif_set_avm_compile_options(avm ${_avm_config})

    # Restore the variables.
    foreach(_config_setting CMAKE_C_FLAGS CMAKE_CXX_FLAGS CMAKE_EXE_LINKER_FLAGS)
        foreach(_config_type DEBUG RELEASE MINSIZEREL RELWITHDEBINFO)
            unset(${_config_setting}_${_config_type} CACHE)
            set(${_config_setting}_${_config_type} ${${_config_setting}_${_config_type}_ORIG} CACHE STRING "" FORCE)
            unset(${_config_setting}_${_config_type}_ORIG)
        endforeach()
    endforeach()
    unset(_config_type)
    unset(_config_setting)
endif()

# If we have libyuv, we disable CONFIG_LIBYUV so that avm does not include the libyuv
# sources from its third-party vendor library. But we still want AVM to have libyuv, only
# linked against this project's target. Here we update the value in avm_config.h and add libyuv
# to AVM's link libraries
if(libyuv_FOUND)
    file(READ ${libavm_BINARY_DIR}/config/avm_config.h AVM_CONFIG_H)
    if("${AVM_CONFIG_H}" MATCHES "CONFIG_LIBYUV 0")
        string(REPLACE "CONFIG_LIBYUV 0" "CONFIG_LIBYUV 1" AVM_CONFIG_H "${AVM_CONFIG_H}")
        file(WRITE ${libavm_BINARY_DIR}/config/avm_config.h "${AVM_CONFIG_H}")
    endif()
    target_link_libraries(avm PRIVATE $<TARGET_FILE:yuv::yuv>)
endif()
# TODO(vrabaud) Remove once libavm properly depends on tensorflow-lite.
target_link_libraries(avm PRIVATE tensorflow-lite)

set_property(TARGET avm PROPERTY AVIF_LOCAL ON)
target_include_directories(avm INTERFACE $<BUILD_INTERFACE:${libavm_SOURCE_DIR}>)

message(CHECK_PASS "complete")
