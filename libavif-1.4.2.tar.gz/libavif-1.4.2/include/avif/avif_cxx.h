// Copyright 2023 Google LLC
// SPDX-License-Identifier: BSD-2-Clause

#ifndef AVIF_AVIF_CXX_H
#define AVIF_AVIF_CXX_H

#if !defined(__cplusplus)
#error "This a C++ only header. Use avif/avif.h for C."
#endif

#include <memory>

#include "avif/avif.h"

namespace avif
{

// Struct to call the destroy functions in a unique_ptr.
struct UniquePtrDeleter
{
    void operator()(avifDecoder * decoder) const { avifDecoderDestroy(decoder); }
    void operator()(avifEncoder * encoder) const { avifEncoderDestroy(encoder); }
    void operator()(avifGainMap * gainMap) const { avifGainMapDestroy(gainMap); }
    void operator()(avifImage * image) const { avifImageDestroy(image); }
};

// Use these unique_ptr to ensure the structs are automatically destroyed.
using DecoderPtr = std::unique_ptr<avifDecoder, UniquePtrDeleter>;
using EncoderPtr = std::unique_ptr<avifEncoder, UniquePtrDeleter>;
using GainMapPtr = std::unique_ptr<avifGainMap, UniquePtrDeleter>;
using ImagePtr = std::unique_ptr<avifImage, UniquePtrDeleter>;

// Automatically cleans the resources of the avifRGBImage.
// To use when RGBImage actually owns the pixels. RGBImage can also be used as a view, in which case it does not own the pixels.
class RGBImageCleanup
{
public:
    RGBImageCleanup(avifRGBImage * rgb) : rgb_(rgb) {}
    ~RGBImageCleanup() { avifRGBImageFreePixels(rgb_); }

private:
    avifRGBImage * rgb_ = nullptr;
};

} // namespace avif

#endif // AVIF_AVIF_CXX_H
