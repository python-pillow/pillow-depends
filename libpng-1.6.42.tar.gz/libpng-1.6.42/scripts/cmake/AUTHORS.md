CMake Files, Lists and Scripts for the PNG Reference Library
============================================================

Author List
-----------

 * Alex Gaynor
 * Andreas Franek
 * B. Scott Michel
 * Cameron Cawley
 * Christian Ehrlicher
 * Christopher Sean Morrison
 * Claudio Bley
 * Clifford Yapp
 * Clinton Ingram
 * Cosmin Truta
 * David Callu
 * Gleb Mazovetskiy
 * Glenn Randers-Pehrson
 * Gunther Nikl
 * Jeremy Maitin-Shepard
 * John Bowler
 * Jon Creighton
 * Kyle Bentley
 * Martin Storsjö
 * Owen Rudge
 * Roger Leigh
 * Roger Lowman
 * Sam Serrels
 * Simon Hausmann
 * Steve Robinson
 * Timothy Lyanguzov
 * Tyler Kropp
 * Vadim Barkov
 * Vicky Pfau
