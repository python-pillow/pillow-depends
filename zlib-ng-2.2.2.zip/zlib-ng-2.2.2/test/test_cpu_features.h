#ifndef TEST_CPU_FEATURES_H
#define TEST_CPU_FEATURES_H

#ifndef DISABLE_RUNTIME_CPU_DETECTION

#  include "cpu_features.h"

extern struct cpu_features test_cpu_features;

#endif

#endif
