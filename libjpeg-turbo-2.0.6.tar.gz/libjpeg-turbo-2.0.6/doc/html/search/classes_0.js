var searchData=
[
  ['tjregion_110',['tjregion',['../structtjregion.html',1,'']]],
  ['tjscalingfactor_111',['tjscalingfactor',['../structtjscalingfactor.html',1,'']]],
  ['tjtransform_112',['tjtransform',['../structtjtransform.html',1,'']]]
];
