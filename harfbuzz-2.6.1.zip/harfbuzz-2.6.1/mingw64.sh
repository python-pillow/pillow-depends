#!/bin/sh
exec "$(dirname "$0")"/mingw-configure.sh x86_64 "$@"
