#include <stdio.h>
#include "zlib-ng.h"

int main(void) {
    printf("zlib-ng: %s\n", ZLIBNG_VERSION);
    return 0;
}
