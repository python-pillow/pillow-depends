from http://www.fileformat.info/format/mspaint/sample/index.htm
