These are images that we can't distribute with Pillow for one reason or another. 
