.. _rfcs:

Request For Comments (RFCs)
===========================

RFCs are the process through which major changes in the working or content
of the libtiff project are conducted.

.. toctree::
    :maxdepth: 1
    :titlesonly:

    rfc1_psc
    rfc2_restoring_needed_tools
