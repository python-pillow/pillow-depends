var searchData=
[
  ['notes_0',['YUV Image Format Notes',['../group___turbo_j_p_e_g.html#autotoc_md0',1,'']]],
  ['num_1',['num',['../structtjscalingfactor.html#a9b011e57f981ee23083e2c1aa5e640ec',1,'tjscalingfactor']]]
];
